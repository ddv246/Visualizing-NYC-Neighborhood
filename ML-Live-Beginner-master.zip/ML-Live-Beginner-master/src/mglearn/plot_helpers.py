from matplotlib.colors import ListedColormap

cm3 = ListedColormap(['b', 'r', 'g'])
cm2 = ListedColormap(['b', 'r'])
