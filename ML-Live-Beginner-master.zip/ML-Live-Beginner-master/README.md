## About the course

This repository **WAS** for use with the Pearson Publishing live webinar "Beginning Machine Learning with `scikit-learn`."  Versions of this material are used by other training provided by David Mertz and [KDM Training](http://kdm.training).

All this content has migrated to [ML-Webinar](https://github.com/DavidMertz/ML-Webinar) repo that unifies the several connected sessions of the same training program.

The content here will not be deleted for a good while, but any improvements, additions, etc. will only live at the unified repository.
